import UIKit

struct Metrics {
	static let blockSize: CGFloat = 15
}
